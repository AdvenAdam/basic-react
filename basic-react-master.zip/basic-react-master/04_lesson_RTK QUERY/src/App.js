import TodoList from "./features/todos/TodoList";

function App() {
  return <TodoList />
}

export default App;

import { useSelector } from 'react-redux';
import { selectAllUsers } from '../users/usersSlice';

function PostsAuthor({ userId }) {
    const users = useSelector(selectAllUsers);
    const author = users.find((user) => user.id === userId);

    return <span> by {author ? author.name : 'unknown'} </span>;
}

export default PostsAuthor;
